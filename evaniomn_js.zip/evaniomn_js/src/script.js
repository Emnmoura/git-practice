let rover = {
    direction: "N",
  x: 0,//x -> collums
  y: 0,//y -> rows
	travel: [],
	obstacle: {x: 3 , y:2}	
}

function GiraRover (robo, command){
  if(command === 'l'){
    switch(robo.direction){
      case "N":
        robo.direction = "W";
        break;
        case "W":
        robo.direction = "S";
        break;
        case "S":
        robo.direction = "E";
        break;
        case "E":
        robo.direction = "N";
        break;	
    }
    }else if(command === 'r'){
switch(robo.direction){
  case "N" : 
    robo.direction = "E";
    break;
    case "E": 
    robo.direction = "S";
    break;
    case "S" : 
    robo.direction = "W";
    break;
    case "W": 
    robo.direction = "N";
    break;
}
		} else {
  console.log(`comando '${command}' não identificado utilize 'r' ou 'l'`)
}
  console.log(`Direção do robo é ${robo.direction}`)
}
function MoveRover (robo, anda){
	//if(robo.x != robo.obstacle.x && robo.y != robo.obstacle.y){
	if(anda === 'f'){
		switch(robo.direction){
		case "N": 
			robo.y--;
			break;
		case "W":
			robo.x--;
			break;
		case "S":
			robo.y++;
			break;
		case "E":
			robo.x++;
			break
		}
	}else if(anda === 'b'){
		switch(robo.direction){
		case "N": 
			robo.y++;
			break;
		case "W":
			robo.x++;
			break;
		case "S":
			robo.y--;
			break;
		case "E":
			robo.x--;
			break
	}
	}else {
		console.log(`comando '${anda}' invalido tente os comandos 'f' ou 'b'`)
	}
	//}
	let local = { x: robo.x, y: robo.y }
	robo.travel.push(local)
}
function ComandosRover (robo, comandos) {
	for (let i = 0; i < comandos.length; i++){
		 let comando = comandos[i]
			switch(comando){
				case 'l' :
					GiraRover(robo, comando);
					break;
					case 'r' :
					GiraRover(robo, comando);
					break;
				case 'f': 
					MoveRover(robo, comando);
					break;
					case 'b': 
					MoveRover(robo, comando);
					break;
				default:
					console.log(`comando '${comandos[i]}' inválido!!!`)
			}
		}
		console.log(robo.travel)
	
	}
ComandosRover(rover, 'rffrfflfrff')

